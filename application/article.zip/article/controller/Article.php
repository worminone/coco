<?php
namespace app\article\controller;

use think\Db;
use app\common\controller\Base;

class Article extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @api {post} /article/Article/articleList 查看文章列表
     * @apiVersion              1.0.0
     * @apiName                 articleList
     * @apiGROUP                Article
     * @apiDescription          查看文章列表
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {String}       title 标题名称（可选）
     * @apiParam {Int}          page 页码（可选），默认为1
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccess {Object}     count 数据总条数<br>
     *                          pagesize 每页数据条数<br>
     *                          data 数据详情<br>
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *      id:  文章ID,
     *      title: 文章标题,
     *      author_name: 编辑笔名,
     *      create_time: 发布日期,
     *      content: 内容,
     *      publish_time: 预发布日期
     * }
     * ]
     * }
     *
     */
    public function articleList()
    {
        $title = input('param.title', '', 'htmlspecialchars');
        $where['status'] = 1;
        if(!empty($title)) {
            $where['title'] = ['like', "%".$title."%"];
        }
        $field = 'id,title,author_id,create_time,content,'.
        'FROM_UNIXTIME(publish_time,"%Y-%m-%d %H:%i:%S") as publish_time';
        $list = $this->getPageList('Article', $where, 'id desc', $field, '');
        if ($list['count'] > 0) {
            $this->response('1', '获取成功', $list);
        } else {
            $this->response('-1', '未查询到数据', $list);
        }
    }

    /**
     * @api {post} /article/Article/addArticle 添加文章
     * @apiVersion              1.0.0
     * @apiName                 addArticle
     * @apiGROUP                Article
     * @apiDescription          添加文章
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          uid   登录用户ID
     * @apiParam {String}       author_name   作者笔名
     * @apiParam {String}       title   文章标题
     * @apiParam {String}       summary   文章摘要
     * @apiParam {String}       tags   文章标签(多个用','分割)
     * @apiParam {String}       content   文章内容
     * @apiParam {String}       publish_time   预发布时间
     * @apiParam {Int}          view_count   访问数
     * @apiParam {Int}          zan_count   点赞数
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     *
     */
    public function addArticle()
    {
        $info = input('param.');
        DB::name('Article')->insert($info);
        $id = Db::name('Article')->getLastInsID();
        $res = model('Article')->setTagCount($id, $info['tags']);
        if ($res) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }

    /**
     * @api {post} /article/Article/editArticle 编辑查看文章
     * @apiVersion              1.0.0
     * @apiName                 editArticle
     * @apiGROUP                Article
     * @apiDescription          编辑查看文章
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *       author_name : 作者笔名
     *       title : 文章标题
     *       summary : 文章摘要
     *       content : 文章内容
     *       tags : 文章标签
     *       create_time : 发布时间
     *       publish_time : 预发布时间
     *       view_count : 访问数
     *       zan_count : 点赞数
     * }
     * ]
     * }
     *
     */
    public function editArticle()
    {
        $id = input('param.id');
        $info = model('Article')->getArticleInfo($id);
        if ($info) {
            $this->response('1', '获取成功', $info);
        } else {
            $this->response('-1', '暂无数据');
        }
    }


    /**
     * @api {post} /article/Article/saveArticle 提交修改文章
     * @apiVersion              1.0.0
     * @apiName                 addArticle
     * @apiGROUP                Article
     * @apiDescription          saveArticle
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     * @apiParam {String}       author_name   作者笔名
     * @apiParam {String}       title   文章标题
     * @apiParam {String}       summary   文章摘要
     * @apiParam {String}       tags   文章标签(多个用','分割)
     * @apiParam {String}       content   文章内容
     * @apiParam {String}       publish_time   预发布时间
     * @apiParam {Int}          view_count   访问数
     * @apiParam {Int}          zan_count   点赞数
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     *
     */
    public function saveArticle()
    {
        $info = input('param.');
        DB::name('Article')->update($info);
        $res = model('Article')->setTagCount($info['id'], $info['tags']);
        if ($res !==false) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }


    /**
     * @api {post} /article/Article/deleteArticle 删除文章
     * @apiVersion              1.0.0
     * @apiName                 deleteArticle
     * @apiGROUP                Article
     * @apiDescription          删除文章
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     */
    public function deleteArticle()
    {
        $id = input("param.id");
        if (empty($id)) {
            $this->response('-1', '数据不能为空');
        }
        $res = DB::name('Article')
            ->where('id', 'in', $ids)
            ->update(['status'=>0]);
        if ($res !==false) {
            $this->response('1', '删除成功');
        } else {
            $this->response('-1', '删除失败');
        }
    }
    /**
     * @api {post} /article/Article/tagList 获取标签
     * @apiVersion              1.0.0
     * @apiName                 tagList
     * @apiGROUP                获取标签
     * @apiDescription          编辑查看文章
     * @apiParam {String}       token 已登录账号的token
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *       names : 标签
     * }
     * ]
     * }
     *
     */
    public function tagList()
    {
        $list = model('Article')->getTagList();
        if ($list) {
            $this->response('1', '获取成功', $list);
        } else {
            $this->response('-1', '未查询到数据', $list);
        }
    }
}
