<?php
namespace app\article\controller;

use think\Db;
use app\common\controller\Base;

class Topic extends Base
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @api {post} /article/Topic/topicList 查看文章列表
     * @apiVersion              1.0.0
     * @apiName                 topicList
     * @apiGROUP                Article
     * @apiDescription          查看文章列表
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {String}       title 标题名称（可选）
     * @apiParam {Int}          page 页码（可选），默认为1
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccess {Object}     count 数据总条数<br>
     *                          pagesize 每页数据条数<br>
     *                          data 数据详情<br>
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *      id:  专题ID,
     *      index_img: 一体机首页图片地址,
     *      name: 专题名称,
     *      term_name: 终端名称,
     *      create_time: 发布时间,
     *      author_name: 作者名称
     *      sort  排序
     *      is_top 是否置顶
     *      status 状态
     *      term_type_name: 专题分类名称
     *      topic_type: 专题分类(1专题 2专业专题 3大学专题)
     * }
     * ]
     * }
     *
     */
    public function topicList()
    {
        $title = input('param.title', '', 'htmlspecialchars');
        $where['status'] = 1;
        if(!empty($title)) {
            $where['title'] = ['like', "%".$title.'%'];
        }
        $list = $this->getPageList('Topic', $where, 'sort,id desc', '*', '');
        foreach ($list['list'] as $key => $value) {
            $t_info = model('Term')->getTermType($value['term_type']);
            $list['list'][$key]['term_name'] =  $t_info['name'];
            if($value['is_top'] == 1) {
                $list['list'][$key]['is_top'] = '是';    
            } else {
                $list['list'][$key]['is_top'] = '否';    
            }
            $topic_type = model('Topic')->getTopicType();
            $list['list'][$key]['term_type_name'] = $topic_type[$value['topic_type']];
        }
        if ($list['count'] > 0) {
            $this->response('1', '获取成功', $list);
        } else {
            $this->response('-1', '未查询到数据', $list);
        }
    }

    /**
     * @api {post} /article/Topic/addTopic 新增专题
     * @apiVersion              1.0.0
     * @apiName                 addTopic
     * @apiGROUP                Article
     * @apiDescription          新增专题
     *
     * @apiParam {String}    token 已登录账号的token
     * @apiParam {String}    name   专题名称
     * @apiParam {Int}       term_type   终端形式
     * @apiParam {Int}       sort   排序
     * @apiParam {Int}       topic_type: 专题分类(1专题 2专业专题 3大学专题)
     * @apiParam {Int}       is_top   是否置顶(1:置顶，0:不置顶)
     * @apiParam {String}    index_img   一体机首页图片地址
     * @apiParam {String}    list_img   专题列表封面图片地址
     * @apiParam {String}    head_img   专题头部位置图片地址
     * @apiParam {String}    author_name   作者名称
     * @apiParam {String}    describe   描述
     * @apiParam {Int}       term_article_id 文章ID(多个用','分割)
     *
     * @apiSuccess {Int}     code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}  msg 成功的信息和失败的具体信息.
     *
     */
    public function addTopic()
    {
        $info = input('param.');
        DB::name('Topic')->insert($info);
        $id = Db::name('Topic')->getLastInsID();
        $term_article_ids = explode(',', $info['term_article_id']);
        $article_topic = '';
        for ($i=0; $i < count($term_article_ids); $i++) { 
            $article_topic[$i]['topic_id'] = $id;
            $article_topic[$i]['term_article_id'] = $term_article_ids[$i];
        }
        $res = DB::name('ArticleTopic')->insertAll($article_topic);
        if ($res) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }

    /**
     * @api {post} /article/Topic/editTopic 编辑查看专题
     * @apiVersion              1.0.0
     * @apiName                 editTopic
     * @apiGROUP                Article
     * @apiDescription          编辑查看专题
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *      id : 专题ID
     *      term_type : 终端类型
     *      author_name  文章分类或者专题分类,(1:文章,2:专题 3轮播图)
     *      name : 分类标题
     *      sort : 分类上级(pid=0 分类上级隐藏)
     *      is_top : 描述
     *      index_img : 一体机首页图 
     *      list_img : 大学列表封面
     *      head_img : 大学头部位置
     *      describe : 描述
     *      term_type: 专题分类(1专题 2专业专题 3大学专题)
     *      article 内容信息
     *            [{
     *                id:  文章ID
     *                title: 文章名称
     *            }]
     * }
     * ]
     * }
     *
     */
    public function editTopic()
    {
        $id = input('param.id');
        $info = model('Topic')->getTopicInfo($id);
        $info['article'] = model('Topic')->getTopicArticleList($id);
        if ($info) {
            $this->response('1', '获取成功', $info);
        } else {
            $this->response('-1', '暂无数据');
        }
    }

    /**
     * @api {post} /article/Topic/saveTopic 提交修改专题
     * @apiVersion              1.0.0
     * @apiName                 saveTopic
     * @apiGROUP                Article
     * @apiDescription          提交修改专题
     *
     * @apiParam {String}    token 已登录账号的token
     * @apiParam {Int}       id   专题ID
     * @apiParam {String}    name   专题名称
     * @apiParam {Int}       term_type   终端形式
     * @apiParam {Int}       sort   排序
     * @apiParam {Int}       topic_type: 专题分类(1专题 2专业专题 3大学专题)
     * @apiParam {Int}       is_top   是否置顶(1:置顶，0:不置顶)
     * @apiParam {String}    index_img   一体机首页图片地址
     * @apiParam {String}    list_img   专题列表封面图片地址
     * @apiParam {String}    head_img   专题头部位置图片地址
     * @apiParam {String}    author_name   作者名称
     * @apiParam {String}    describe   描述
     * @apiParam {Int}       term_article_id 文章ID(多个用','分割)
     *
     * @apiSuccess {Int}     code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}  msg 成功的信息和失败的具体信息.
     *
     */
    public function saveTopic()
    {
        $info = input('param.');
        DB::name('Topic')->update($info);
        $term_article_ids = explode(',', $info['term_article_id']);
        DB::name('ArticleTopic')
            ->where(['topic_id'=>$info['id']])
            ->delete();
        $article_topic='';
        for ($i=0; $i < count($term_article_ids); $i++) { 
            $article_topic[$i]['topic_id'] = $info['id'];
            $article_topic[$i]['term_article_id'] = $term_article_ids[$i];
        }
        $res = DB::name('ArticleTopic')->insertAll($article_topic);
         if ($res !==false) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }

    /**
     * @api {post} /article/Topic/deleteTopic 删除专题
     * @apiVersion              1.0.0
     * @apiName                 deleteTopic
     * @apiGROUP                Article
     * @apiDescription          删除专题
     *
     * @apiParam {String}    token 已登录账号的token
     * @apiParam {Int}       id   专题ID
     * @apiSuccess {Int}     code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}  msg 成功的信息和失败的具体信息.
     *
     */
    public function deleteTopic()
    {
        $id = input("param.id");
        if(empty($id)) {
            $this->response('-1', '数据不能为空');
        }
        $res = DB::name('Topic')
            ->where('id', 'in', $id)
            ->update(['status'=>0]);
        if ($res !==false) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }


    /**
     * @api {post} /article/Topic/topicTypeList 专题分类列表
     * @apiVersion              1.0.0
     * @apiName                 topicTypeList
     * @apiGROUP                Article
     * @apiDescription          专题分类列表
     * @apiParam {String}       token 已登录账号的token
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *      id: 专题分类ID,
     *      name: 专题分类名称,
     * }
     * ]
     * }
     *
     */
    public function topicTypeList()
    {
        $list = model('Topic')->getTopicTypeList();
        if ($list) {
            $this->response('1', '获取成功', $list);
        } else {
            $this->response('-1', '未查询到数据', $list);
        }
    }

}
