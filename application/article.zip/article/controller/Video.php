<?php
namespace app\article\controller;

use think\Db;
use app\common\controller\Base;

class Video extends Base
{   
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @api {post} /article/Article/articleList 查看文章列表
     * @apiVersion              1.0.0
     * @apiName                 articleList
     * @apiGROUP                Article
     * @apiDescription          查看文章列表
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {String}       title 标题名称（可选）
     * @apiParam {Int}          page 页码（可选），默认为1
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccess {Object}     count 数据总条数<br>
     *                          pagesize 每页数据条数<br>
     *                          data 数据详情<br>
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *       id      ID
     *       cover   封面，列表页图片url地址   
     *       title   标题
     *       c_name  分类
     *       sort    排序
     *       t_name  终端
     *       is_top  是否置顶
     *       status  状态
     *       create_time  创建日期
     * }
     * ]
     * }
     *
     */
    public function videoList()
    {
        $title = input('param.title', '', 'htmlspecialchars');
        $where['status'] = 1;
        if(!empty($title)) {
            $where['title'] = ['like', "%".$title."%"];
        }
        $field = 'id,title,is_top,cover,sort,category_id,create_time,content,term_type';
        $list = $this->getPageList('Video', $where, 'id desc', $field, '');
        foreach ($list['list'] as $key => $value) {
            $t_info = model('Term')->getTermType($value['term_type']);
            $c_info = model('Category')->getCategoryInfo($value['category_id']);

            if(empty($c_info)) {
                unset($list['list'][$key]);
                continue;
            }
            if($value['is_top'] == 1) {
                $list['list'][$key]['is_top'] = '是';
            } else {
                $list['list'][$key]['is_top'] = '否';
            }
            $list['list'][$key]['t_name'] = $t_info['name'];
            $list['list'][$key]['c_name'] = $c_info['name'];

        }
        if ($list['count'] > 0) {
            $this->response('1', '获取成功', $list);
        } else {
            $this->response('-1', '未查询到数据', $list);
        }
    }

    /**
     * @api {post} /article/Article/addVideo 添加视频
     * @apiVersion              1.0.0
     * @apiName                 addVideo
     * @apiGROUP                Article
     * @apiDescription          添加视频
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id  文章分类ID
     * @apiParam {Int}          article_id   公共文章ID
     * @apiParam {Int}          term_type   终端类型
     * @apiParam {String}       cover   封面，列表页图片url地址   
     * @apiParam {Int}          play_type   视频源来源地址,1:本地上传,2:iframe网页来源,3:外链视频源地址
     * @apiParam {String}       content   如果是play_type是1的话，就是admin_upload的id，不是就是网页或者视频源地址
     * @apiParam {String}       title   标题
     * @apiParam {String}       description   简介
     * @apiParam {Int}          sort   排序
     * @apiParam {Int}          tags   便签(多个','分割)
     * @apiParam {Int}          is_top   是否置顶
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     *
     */
    public function addVideo()
    {
        $info = input('param.');
        DB::name('Video')->insert($info);
        $id = Db::name('Video')->getLastInsID();
        $res = model('Video')->setTagCount($id, $info['tags']);
        if ($res) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }

    /**
     * @api {post} /article/Article/editVideo 编辑查看视频
     * @apiVersion              1.0.0
     * @apiName                 editVideo
     * @apiGROUP                Article
     * @apiDescription          编辑查看视频
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     * @apiSuccessExample  {json} Success-Response:
     * {
     * "code": 1,
     * "msg": "获取成功",
     * "data": [
     * {
     *       category_id   文章分类ID
     *       article_id   公共文章ID
     *       term_type   终端类型
     *       cover   封面，列表页图片url地址   
     *       play_type   视频源来源地址,1:本地上传,2:iframe网页来源,3:外链视频源地址
     *       content   如果是play_type是1的话，就是admin_upload的id，不是就是网页或者视频源地址
     *       title   标题
     *       description   简介
     *       sort   排序
     *       tags   便签(多个','分割)
     *       is_top   是否置顶
     * ]
     * }
     *
     */
    public function editVideo()
    {
        $id = input('param.id');
        $info = model('Video')->getVideoInfo($id);
        if ($info) {
            $this->response('1', '获取成功', $info);
        } else {
            $this->response('-1', '暂无数据');
        }
    }


    /**
     * @api {post} /article/Article/saveVideo 提交修改视频
     * @apiVersion              1.0.0
     * @apiName                 saveVideo
     * @apiGROUP                Article
     * @apiDescription          提交修改视频
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          category_id   文章分类ID
     * @apiParam {Int}          article_id   公共文章ID
     * @apiParam {Int}          term_type   终端类型
     * @apiParam {String}       cover   封面，列表页图片url地址   
     * @apiParam {Int}          play_type   视频源来源地址,1:本地上传,2:iframe网页来源,3:外链视频源地址
     * @apiParam {String}       content   如果是play_type是1的话，就是admin_upload的id，不是就是网页或者视频源地址
     * @apiParam {String}       title   标题
     * @apiParam {String}       description   简介
     * @apiParam {Int}          sort   排序
     * @apiParam {Int}          tags   便签(多个','分割)
     * @apiParam {Int}          is_top   是否置顶
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     *
     */
    public function saveVideo()
    {
        $info = input('param.');
        DB::name('Video')->update($info);
        $res = model('Video')->setTagCount($info['id'], $info['tags']);
        if ($res !==false) {
            $this->response('1', '你的信息已提交');
        } else {
            $this->response('-1', '信息提交失败');
        }
    }


    /**
     * @api {post} /article/Article/deleteVideo 删除视频
     * @apiVersion              1.0.0
     * @apiName                 deleteVideo
     * @apiGROUP                Article
     * @apiDescription          删除视频
     * @apiParam {String}       token 已登录账号的token
     * @apiParam {Int}          id   文章ID
     *
     * @apiSuccess {Int}        code 错误代码，1是成功，-1是失败.
     * @apiSuccess {String}     msg 成功的信息和失败的具体信息.
     */
    public function deleteVideo()
    {
        $id = input("param.id");
        if (empty($id)) {
            $this->response('-1', '数据不能为空');
        }
        $res = DB::name('Video')
            ->where('id', 'in', $ids)
            ->update(['status'=>0]);
        if ($res !==false) {
            $this->response('1', '删除成功');
        } else {
            $this->response('-1', '删除失败');
        }
    }
}
