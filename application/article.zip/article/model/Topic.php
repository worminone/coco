<?php

namespace app\article\model;

use think\Db;

class Topic
{
    public $topic_type = [
                '1'=>'专题',
                '2'=>'专业专题',
                '3'=>'大学专题'
            ];
    //ID 获取 咨询信息
    public function getTopicInfo($id)
    {
        return DB::name('Topic')
            ->where(['id'=>$id])
            ->find();
    }

    //获取专题类别信息
    public function getTopicType()
    {
        return DB::name('TopicType')->column('name', 'id');
    }

    //获取专题类别列表
    public function getTopicTypeList()
    {
        return DB::name('TopicType')->select();
    }


    public function getTopicArticleInfo($id,$limit)
    {
        $term = new Term();
        $author = new Author();
        $t_info = DB::name('Topic')
            ->field('id,term_type,name,describe,head_img,recommend')
            ->where(['id'=>$id])
            ->find();
        if($t_info['recommend'] != '') {
            $t_info['recommend'] = substr($a_info['recommend'],0,50);
        }
        $term_info = $term->getTermType($t_info['term_type']);
        $t_info['term_name'] = $term_info['name'];

   		$info = DB::name('ArticleTopic')
            ->where(['topic_id'=>$id])
            ->limit($limit)
            ->select();
        foreach ($info as $key => $value) {
            $a_info = DB::name('Article')
                ->where(['id'=>$value['term_article_id']])
                ->find();
            //此处缺失笔名信息和转专业大学有信息
            // $info[$key]['author_id'] = $a_info['author_id'];
            $author_info = $author->getAuthorInfo($a_info['author_id']);
            $info[$key]['avatar'] = $author_info['avatar'];
            $info[$key]['username'] = $author_info['username'];
            $info[$key]['title'] = $a_info['title'];
            $info[$key]['img'] = $a_info['img'];
            $info[$key]['content']  = substr(strip_tags($a_info['content']),0,50);
            $info[$key]['publish_time'] = wordTime($a_info['publish_time']);
        }
        $t_info['article'] = $info;
        return $t_info;
    }

    //获取专题信息
    public function getTopicList($id)
    {
        return DB::name('Topic')
            ->where(['id'=>$id])
            ->find();
    }

    //专题下的文章信息
    public function getTopicArticleList($topic_id)
    {
        $list = DB::name("ArticleTopic")
            ->where(['topic_id'=>$topic_id])
            ->select();

        foreach ($list as $key => $value) {
            $info = model('Article')->getArticleInfo($value['term_article_id']);
            if(empty($info)) {
                unset($list[$key]);
                continue;
            }
            $list[$key]['title'] = $info['title'];
        }
        return $list;
    }

    //前端获取专题信息列表
    public function getTopicCoverList($where, $field, $limit, $order)
    {
        return DB::name('Topic')
                ->field($field)
                ->where($where)
                ->limit($limit)
                ->order($order)
                ->select();
    }
}
