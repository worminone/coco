<?php

namespace app\article\model;

use think\Db;

class Article
{
    //ID 获取 文章信息
    public function getArticleInfo($id)
    {
        $author = new Author;
        $info = DB::name('Article')
            ->where(['id'=>$id, 'status'=>1])
            ->find();
        $author_info = $author->getAuthorInfo($info['author_id']);
        $info['avatar'] = $author_info['avatar'];
        $info['username'] = $author_info['username'];
        $tag_map = DB::name('TagMap')->where(['post_id'=>$id, 'type'=>1])->column('tag_id');
        $tag = DB::name('Tags')->column('name','id');
        $tags = '';
        for ($i=0; $i < count($tag_map); $i++) { 
            $tags[] = $tag[$tag_map[$i]];
        }
        if($tags !='') {
            $info['tags'] = implode(',', $tags);
        } else {
             $info['tags'] = '';
        }
        
        return $info;
    }

    //标题 获取 文章ID
    public function getArticleFromTitle($where)
    {
        return DB::name('Article')
            ->where($where)
            ->column('id');
    }


    public function addViewCount($id)
    {
       return DB::name('Article')->where(['id'=>$id])->setInc('view_count', 1);
    }

    //获取关联多的标签
    public function getTagList()
    {
        $info['names'] = DB::name('Tags')->order('count desc')->limit(10)->column('name');
        return $info;

    }

    //添加到关键词中

    public function setTagCount($id, $names)
    {
        
        $name = explode(',', $names);
        $tags_name = '';
        foreach ($name as $key => $value) {
            $info = DB::name('Tags')->where(['name'=>$value])->find();
            if(empty($info)) {
                DB::name('Tags')->insert(['name'=>$value]);
                $tid = Db::name('Tags')->getLastInsID();
                $data = ['post_id'=>$id,'tag_id'=>$tid];
            } else {
                DB::name('Tags')->where(['name'=>$value])->setInc('count');
                $data = ['post_id'=>$id,'tag_id'=>$info['id']];
            }
            $tags_name[] = $data;
        }
        DB::name('TagMap')->where(['post_id'=>$id])->delete();
        return  DB::name('TagMap')->insertAll($tags_name);
    }

}
