<?php

namespace app\article\model;

use think\Db;

class Category
{
    //ID 获取 顶级分类列表
    public function getCategoryOneInfo($where)
    {
        return DB::name('ArticleCategory')
        	->field('id,name')
            ->where($where)
            ->select();
    }


    //ID 获取 当前分类信息和上级分类信息
    public function getCategoryInfo($id)
    {
        $info = DB::name('ArticleCategory')
            ->where(['id'=>$id, 'status'=>1])
            ->find();
        if($info['pid'] != 0) {
        	$top_info = DB::name('ArticleCategory')
		        ->where(['id'=>$info['pid'], 'status'=>1])
	            ->find();
         	$info['catrgory_top_name'] = $top_info['name'];
        }
        return $info;
	        
    }

    //获取分类列表
    public function getCategoryList($where)
    {
    	$page = input('param.page', '1', 'intval');
        $limit = config('paginate.list_rows');
        $count =  DB::name('ArticleCategory')
            ->where($where)
            ->count();
        $page_num = ceil($count/$limit);
        $list =  DB::name('ArticleCategory')
        	->field('id,name')
            ->where($where)
            ->limit($limit*($page-1), $limit)
            ->select();
        foreach ($list as $key => $value) {
        	$p_list = DB::name('ArticleCategory')
        		->field('id,name')
	        	->where(['pid'=>$value['id']])
	        	->select();
	        $list[$key]['catrgory'] = $p_list;

        }
        if (!empty($list)) {
            $data = [
                'count'   => $count,
                'page_num'=> $page_num,
                'list'    => $list
            ];
        } else {
            $data = [
                'count'   => 0,
                'page_num'=> $page_num,
                'list'    => []
            ];
        }
        return $data;
    }

    //获取类型分类列表
    public function getCategoryTermList($where, $field)
    {
    	return DB::name('ArticleCategory')
    		->field($field)
    		->where($where)
    		->select();
    }

    //获取类型分类id
    public function getCategoryTermIds($where)
    {
        return DB::name('ArticleCategory')
            ->where($where)
            ->column('id');
    }
}
