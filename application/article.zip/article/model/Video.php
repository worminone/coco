<?php

namespace app\article\model;

use think\Db;

class Video
{
    //ID 获取 文章信息
    public function getVideoInfo($id)
    {
        $info = DB::name('Video')
            ->where(['id'=>$id, 'status'=>1])
            ->find();
        $tag_map = DB::name('TagMap')->where(['post_id'=>$id, 'type'=>2])->column('tag_id');
        $tag = DB::name('Tags')->column('name','id');
        $tags = '';
        for ($i=0; $i < count($tag_map); $i++) { 
            $tags[] = $tag[$tag_map[$i]];
        }
        $info['tags'] = implode(',', $tags);
        return $info;
    }



    //添加到关键词中

    public function setTagCount($id, $names)
    {
        
        $name = explode(',', $names);
        $tags_name = '';
        foreach ($name as $key => $value) {
            $info = DB::name('Tags')->where(['name'=>$value])->find();
            if(empty($info)) {
                DB::name('Tags')->insert(['name'=>$value]);
                $tid = Db::name('Tags')->getLastInsID();
                $data = ['post_id'=>$id,'tag_id'=>$tid,'type'=>2];
            } else {
                DB::name('Tags')->where(['name'=>$value])->setInc('count');
                $data = ['post_id'=>$id,'tag_id'=>$info['id'],'type'=>2];
            }
            $tags_name[] = $data;
        }
        DB::name('TagMap')->where(['post_id'=>$id])->delete();
        return  DB::name('TagMap')->insertAll($tags_name);
    }

    //公用接口 获取视频列表
    public function getVideoList($where, $field, $limit, $order)
    {
       return  DB::name('Video')
                ->field($field)
                ->where($where)
                ->limit($limit)
                ->order($order)
                ->select();
    }

}
