<?php

namespace app\article\model;

use think\Db;

class Term
{
    //ID 获取 文章内容信息
    public function getTermInfo($aid)
    {
        $list = DB::name('TermArticle')
            ->where(['article_id'=>$aid, 'status'=> 1])
            ->select();
        $lists='';
        foreach ($list as $key => $value) {
            $c_info = model('category')->getCategoryInfo($value['category_id']);
            if(empty($c_info)) {
                unset($list[$key]);
                continue;
            }
            $lists['id'][] = $value['id'];
            $lists['category_id'][] = $value['category_id'];
            $lists['category_top_id'][] = $c_info['pid'];
            $lists['term_type'][] = $value['term_type'];
            $lists['is_top'][] = $value['is_top'];
            $lists['cover'][] = $value['cover'];
            $lists['head_img'][] = $value['head_img'];
            $lists['article_id'] = $aid;
        }
        return $lists;
    }

    public function getTermType($id)
    {
        return DB::name('TermType')
            ->where(['id'=>$id])
            ->find();
    }

    public function getTermTypeInfo()
    {
        return DB::name('TermType')->select();
    }


    //三端的数据列表文章内容
    public function getTermList($where, $field, $limit, $order)
    {
        $author = new Author;
        $term_article = DB::name('TermArticle')
            ->field($field)
            ->where($where)
            ->order($order)
            ->limit($limit)
            ->select();

        foreach ($term_article as $key => $value) {
            $a_info = DB::name('Article')
                ->where(['id'=>$value['article_id']])
                ->find();
            //此处缺失笔名信息和转专业大学有信息
            $author_info = $author->getAuthorInfo($a_info['author_id']);
            $term_article[$key]['avatar'] = $author_info['avatar'];
            $term_article[$key]['username'] = $author_info['username'];
            $term_article[$key]['title'] = $a_info['title'];
            $term_article[$key]['img'] = $a_info['img'];
            if($a_info['content'] !='') {
                $term_article[$key]['content']  = substr(strip_tags($a_info['content']),0,50);
            }
            $term_article[$key]['publish_time'] = wordTime($a_info['publish_time']);
        }
        return $term_article; 
    }

}
